module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const body=req.body||{};
    const setId=String(body.setId||'').trim();
    const code=String(body.code||body.setCode||'').trim().toUpperCase();
    const localId=String(body.localId||body.number||'').trim();
    const langs=Array.isArray(body.langs)&&body.langs.length?body.langs.map(x=>String(x).trim()).filter(Boolean):['en','es'];
    if(!localId||(!setId&&!code))return res.status(400).json({error:'Faltan código y número de carta.'});
    const cleanNum=localId.split('/')[0].trim();
    const uniqueLangs=[...new Set(langs)];
    const normalizedCode=code.toUpperCase();
    const japaneseCode=/^(SV\d+[A-Z]?|M\d+[A-Z]?|S\d+[A-Z]?|SM\d+[A-Z]?|XY\d+|BW\d+|M-PRO|M-P)$/.test(normalizedCode);
    const decode=s=>String(s||'').replace(/&amp;/gi,'&').replace(/&#39;|&#x27;/gi,"'").replace(/&quot;|&#x22;/gi,'"').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCharCode(parseInt(n,16)));
    const strip=x=>decode(String(x||'').replace(/<[^>]+>/g,' ')).replace(/\s+/g,' ').trim();

    // Convierte la ruta de imagen que entrega TCGdex en la URL REAL del archivo.
    // La guardamos y devolvemos tal cual para que PokeScan no tenga que volver a
    // adivinar la ruta de la imagen al abrir la colección.
    const resolveTcgdexImage=async image=>{
      const base=String(image||'').trim();
      if(!base)return '';
      const candidates=/\.(?:png|jpe?g|webp)(?:$|[?#])/i.test(base)
        ? [base]
        : [base.replace(/\/$/,'')+'/high.webp',base.replace(/\/$/,'')+'/high.png',base.replace(/\/$/,'')+'/low.webp'];
      for(const u of candidates){
        try{
          const hr=await fetch(u,{method:'HEAD',headers:{Accept:'image/*'},cache:'no-store'});
          if(hr.ok && String(hr.headers.get('content-type')||'').toLowerCase().startsWith('image/')) return u;
        }catch(e){}
        try{
          const gr=await fetch(u,{headers:{Accept:'image/*'},cache:'no-store'});
          if(gr.ok && String(gr.headers.get('content-type')||'').toLowerCase().startsWith('image/')){
            await gr.arrayBuffer();
            return u;
          }
        }catch(e){}
      }
      return '';
    };

    // 1) TCGdex: fuente principal. Si no conocemos el setId interno,
    // intentamos descubrirlo dinámicamente usando el código impreso. TCGdex
    // expone la colección de sets y su campo tcgOnline, lo que permite que
    // una expansión nueva se resuelva sin añadirla manualmente al catálogo.
    const trySetIds=[...new Set([setId, normalizedCode.toLowerCase()].filter(Boolean))];
    for(const lang of uniqueLangs){
      // Descubrimiento dinámico: primero probamos el código como id; si falla,
      // buscamos en la lista de sets por tcgOnline o id.
      if(normalizedCode){
        try{
          const sr=await fetch(`https://api.tcgdex.net/v2/${encodeURIComponent(lang)}/sets`,{headers:{Accept:'application/json'},cache:'no-store'});
          if(sr.ok){
            const sets=await sr.json();
            if(Array.isArray(sets)){
              const match=sets.find(st=>{
                const id=String(st?.id||'').toUpperCase();
                const tcg=String(st?.tcgOnline||'').toUpperCase();
                return id===normalizedCode || tcg===normalizedCode;
              });
              if(match?.id) trySetIds.push(String(match.id));
            }
          }
        }catch(e){}
      }
    }
    for(const sidCandidate of [...new Set(trySetIds)]){
      for(const lang of uniqueLangs){
        const urls=[
          `https://api.tcgdex.net/v2/${encodeURIComponent(lang)}/sets/${encodeURIComponent(sidCandidate)}/${encodeURIComponent(cleanNum)}`,
          `https://api.tcgdex.net/v2/${encodeURIComponent(lang)}/cards/${encodeURIComponent(sidCandidate+'-'+cleanNum)}`
        ];
        for(const url of urls){
          try{
            const r=await fetch(url,{headers:{Accept:'application/json'},cache:'no-store'});
            if(!r.ok)continue;
            const card=await r.json();
            if(card&&String(card.name||'').trim()){
              const image=String(card.image||'').trim();
              const imageUrl=await resolveTcgdexImage(image);
              let englishName=String(card.name||'').trim();
              if(String(lang).toLowerCase()!=='en'){
                try{
                  const enUrl=`https://api.tcgdex.net/v2/en/cards/${encodeURIComponent(sidCandidate+'-'+cleanNum)}`;
                  const er=await fetch(enUrl,{headers:{Accept:'application/json'},cache:'no-store'});
                  if(er.ok){const ec=await er.json();if(ec&&String(ec.name||'').trim())englishName=String(ec.name).trim();}
                }catch(e){}
              }
              const cardmarketProductId=String(card?.pricing?.cardmarket?.idProduct||card?.thirdParty?.cardmarket||'').trim();
              return res.status(200).json({...card,image,imageUrl:imageUrl||image,cardmarketProductId,cardmarketNameEnglish:englishName,source:'TCGdex',sourceUrl:url,discoveredSetCode:normalizedCode,discoveredSetId:String(card?.set?.id||sidCandidate),discoveredExpansion:String(card?.set?.name||'').trim()});
            }
          }catch(e){}
        }
      }
    }

    // 2) Limitless: respaldo por código + número exactos, sin buscar por nombre.
    // 30C usa números de tres cifras en Cardmarket/TCG, pero Limitless puede
    // publicar la ficha con el número sin ceros iniciales. Probamos ambas formas.
    if(code){
      const nums=[cleanNum];
      const unpadded=String(cleanNum).replace(/^0+/,'')||String(cleanNum);
      if(unpadded && unpadded!==cleanNum) nums.push(unpadded);
      const urls=[];
      for(const n of nums){
        for(const lang of uniqueLangs){
          const l=String(lang).toLowerCase()==='es'?'es':'en';
          urls.push(`https://limitlesstcg.com/cards/${l}/${encodeURIComponent(code)}/${encodeURIComponent(n)}`);
        }
        urls.push(`https://limitlesstcg.com/cards/${encodeURIComponent(code)}/${encodeURIComponent(n)}`);
      }
      for(const url of [...new Set(urls)]){
        try{
          const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (compatible; PokeScan/1.0)','Accept':'text/html,application/xhtml+xml'},cache:'no-store'});
          if(!r.ok)continue;
          const html=await r.text();
          const first=(re)=>{const m=html.match(re);return m&&m[1]?strip(m[1]):''};
          const heading=first(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
          const ogTitle=first(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)||first(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i);
          const title=first(/<title[^>]*>([\s\S]*?)<\/title>/i);
          let name='';
          for(const raw of [heading,ogTitle,title]){
            if(!raw)continue;
            const n=raw.replace(/\s*[-–—]\s*(?:30th Celebration|[^-–—]+)?\s*\([^)]*\)\s*#?\d+.*$/i,'').trim();
            if(n){name=n;break;}
          }
          if(!name)continue;
          const image=first(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)||first(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
          const canonical=first(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i)||url;
          const codeEsc=code.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
          const setMatch=html.match(new RegExp('>([^<>]{2,100})\\s*\\(\\s*'+codeEsc+'\\s*\\)\\s*#','i'));
          const setName=setMatch?strip(setMatch[1]):'';
          return res.status(200).json({name,localId:cleanNum,id:code+'-'+cleanNum,number:cleanNum,image,imageUrl:image,set:{id:code,name:setName},source:'Limitless',sourceUrl:canonical,cardmarketNameEnglish:name});
        }catch(e){}
      }
    }
    return res.status(404).json({error:`No se encontró ${code?code+' ':''}${cleanNum} en las fuentes externas.`});
  }catch(e){return res.status(500).json({error:e?.message||'Error interno.'});}
};
